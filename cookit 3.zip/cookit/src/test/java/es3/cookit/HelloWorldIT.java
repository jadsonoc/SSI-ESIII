package es3.cookit;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class HelloWorldIT extends HelloWorldTest {
    // Execute the same tests but in packaged mode.
}
